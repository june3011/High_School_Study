import { Student } from "../../type/Student/student";

export type getStudentsResponse = Student[];
