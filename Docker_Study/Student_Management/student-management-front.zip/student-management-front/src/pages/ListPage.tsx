import List from "../components/List";

const ListPage = () => {
  return <List />;
};

export default ListPage;
