import Register from "../components/Register";

const RegisterPage = () => {
  return <Register />;
};

export default RegisterPage;
