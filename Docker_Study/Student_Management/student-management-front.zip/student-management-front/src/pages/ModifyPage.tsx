import Modify from "../components/Modify";

const ModifyPage = () => {
  return <Modify />;
};

export default ModifyPage;
